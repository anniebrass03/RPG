# Inventory of evidence
evidence = ['Pencil', 'Hair', 'Blue Fabric']

print ("\nHere is the inventory of evidence:")
print('\n'.join(evidence))
print ("\nYou can examine the evidence by going to the Lab map.\n")
