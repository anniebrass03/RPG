from map_class import Map


# Class for inventory
class Inventory(Map):
  def __init__(self, map_name, map_info, one, two):
    Map.__init__(self, map_name, map_info)
    self.one = one
    self.two = two

# Description of inventory
  def inventory_description(self):
    print (f'\nThe {self.map_name} map has items that examines evidence.')
    print (f'{self.one}: scans evidence for fingerprints')
    print (f'{self.two}: identifies compounds on evidence')
