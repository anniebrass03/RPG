from map_class import Map


# Class for directions
class Directions(Map):

  directions = ""

  def __init__(self, map_name, map_info, directions):
    Map.__init__(self, map_name, map_info)
    self.directions = directions

  def show_directions(self):
    print('\nThere are four ways to go through the map: ')
    return self.directions
