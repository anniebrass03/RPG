# Course: CS 30
# Period: 1
# Date created: Feb 21st 2021
# Date last modified: Feb 22st 2021
# Name: Annabelle Brass
# Description: Classes for RPG

from map_class import Map
from directions_class import Directions
from inventory_class import Inventory

# Making instances for map
# FBI map
place = Map('FBI', 'suspects')
place.map_description()

info = Directions('FBI', 'suspects', 'left, right, up and down\n')
print(info.show_directions())

# Lab map
place = Map('Lab', 'evidence')
place.map_description()

info = Directions('Lab', 'evidence', 'left, right, up and down')
print(info.show_directions())

# Making instances for inventory
things = Inventory('Lab', 'evidence', '* Fingerprint scanner', '* Mass-spec')
things.inventory_description()
