# Class for map information
class Map:
  def __init__(self, map_name, map_info):
    self.map_name = map_name
    self.map_info = map_info

  def map_description(self):
    print (f'The {self.map_name} map has the {self.map_info}.')
