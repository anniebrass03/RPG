# Course: CS 30
# Period: 1
# Date started: Feb 4th 2021
# Date last modifed: Feb 4th 2021
# Name: Annabelle Brass
# Description RPG continuous game play

# Lists
suspects = ['* Blake Morris', '* Patty Rose', '* Emily Joy']
evidence = ['* pencil', '* hair', '* blue fabric']

# Printing the intructions and valid actions
print ("Valid actions you can do:")
print ("Chose someone to investigate:")
print ('\n'.join(suspects))
print ("Choose an item in evidence to process:")
print ('\n'.join(evidence))
print ('\n(Enter choice as shown exactly in list)')
print ("(Enter 'quit' to stop gameplay)")

# If elif and else statement according to player choice
while True:
  items = input('Enter choice: ')
  # Code to allow user to quit gameplay
  if items == ('quit'):
    break
  # If, elif statements for suspect and evidence choices
  if items == ('Blake Morris'):
    print ("You are going to interview Blake Morris.")
  elif items == ('Patty Rose'):
    print ('Patty Rose is ready for you.')
  elif items == ('Emily Joy'):
    print ("You are on your way to interview Emily Joy.")
  elif items == ('pencil'):
    print ('You took out the pencil for processing.')
  elif items == ('hair'):
    print ('You are testing the hair.')
  elif items == ('blue fabric'):
    print ('You take the blue fabric to be analysed.')
  # Else statement for invalid input
  else:
    print ('Invalid answer, please enter valid answer.')
