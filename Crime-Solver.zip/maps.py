# Both lists for map for the RPG

# Items in FBI Map
data = [['Patty Rose', '  Clue'], ['START', '\t\t  LAB'], ['Blake Morris', '   ']]

# Items in Lab map
data_1 = [['Pencil', 'FBI'], ['START', ' Blue fabric'], ['Clue', '  Hair']]
