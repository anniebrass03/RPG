from maps import data_1
import sys, importlib


print("Map for Lab:\n")
# Code to print out the Lab map
for i in range(len(data_1)):
  for j in range(len(data_1[i])):
    print(data_1[i][j], end='  ')
  print()

# While loop for possible moves to make on starting position
while True:
  direc = (
      '\n* up (Pencil)',
      '* down (Clue)',
      '* right (Blue fabric)',
      '* solved (If you believe you have the answer)'
      )
  print('\n'.join(direc))
  direct = input('\nEnter direction: ')
  if direct == 'down':
    while True:
      modulename = 'lab_clue'
      if modulename not in sys.modules:
        import lab_clue as lab_clue
        break
      else:
        importlib.reload(sys.modules['lab_clue'])
        import lab_clue as lab_clue
        break
    break
  if direct == 'up':
    while True:
      modulename = 'pencil'
      if modulename not in sys.modules:
        import pencil as pencil
        break
      else:
        importlib.reload(sys.modules['pencil'])
        import pencil as pencil
        break
      break
  if direct == 'right':
    while True:
      modulename = 'blue_fabric'
      if modulename not in sys.modules:
        import blue_fabric as blue_fabric
        break
      else:
        importlib.reload(sys.modules['blue_fabric'])
        import blue_fabric as blue_fabric
        break
      break
  if direct == 'solved' or direct == 'Solved':
    while True:
      modulename = 'ending'
      if modulename not in sys.modules:
        import ending as ending
        break
      else:
        importlib.reload(sys.modules['ending'])
        import ending as ending
        break
      break
  else:
    print("Invalid.")
