from maps import data
import sys, importlib

print("Here is your clue:")
print ('The mass-spec is your friend.\n')


class Clue:
  while True:
    # Map for lab
    print('Map of Lab:\n')
    for i in range(len(data)):
      for j in range(len(data[i])):
        print(data[i][j], end='  ')
      print()
    e = input('Where do you want to go: Patty or Lab: ')
    if e == 'Patty' or e == 'patty':
      while True:
        modulename = 'patty'
        if modulename not in sys.modules:
          import patty as patty
          break
        else:
          importlib.reload(sys.modules['patty'])
          import patty as patty
          break
        break
    if e == 'lab' or e == 'Lab':
      while True:
        modulename = 'lab'
        if modulename not in sys.modules:
          import lab as lab
          break
        else:
          importlib.reload(sys.modules['lab'])
          import lab as lab
          break
        break
    else:
      print('Invalid, please input valid answer.')
      break
    break
