from maps import data, data_1
import sys, importlib

# While loop for analysing blue fabric
while True:
  print("You are examining the fabric.")
  print("Would you like to use the finger print scanner or the mass-spec?")
  scc = input('mass-spec or fingerprint: ')
  if scc == 'mass-spec':
    print('The fabric has some plaster particulates on it.\nUsually found on casts.')
    break
  if scc == 'fingerprint' or scc == 'Fingerprint':
    print('There are only partial prints, not detectable.')
    break
  else:
    print("Invalid.")


# Position in map if you choose blue fabric
class Fabric:
  while True:
    print("Map for Lab:\n")
# Code to print out the Lab map
    for i in range(len(data_1)):
      for j in range(len(data_1[i])):
        print(data_1[i][j], end='  ')
      print()
    f = input('\nstart, fbi or hair: ')
    if f == 'start' or f == 'Start':
      while True:
        modulename = 'lab'
        if modulename not in sys.modules:
          import lab as lab
          break
        else:
          importlib.reload(sys.modules['lab'])
          import lab as lab
          break
        break
    if f == 'FBI' or f == 'fbi':
      while True:
        modulename = 'fbi'
        if modulename not in sys.modules:
          import fbi as fbi
          break
        else:
          importlib.reload(sys.modules['fbi'])
          import fbi as fbi
          break
        break
    if f == 'hair' or f == 'Hair':
      while True:
        modulename = 'hair'
        if modulename not in sys.modules:
          import hair as hair
          break
        else:
          importlib.reload(sys.modules['hair'])
          import hair as hair
          break
        break
    else:
      print('Invalid, please input valid answer.')
