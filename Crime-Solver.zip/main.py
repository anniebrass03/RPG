# Course: CS 30
# Period: 1
# Date started: Feb 21nd 2021
# Date last modified: Feb 26th 2021
# Name: Annabelle Brass
# Description: Clue inspired text-based RGP game

import sys, importlib
import start

# Start of game
while True:
  do = input('Enter choice (start/quit): ')
  if do == 'start' or do == 'Start':
    actions = ['* FBI (suspects map)', '* Lab (evidence map)']
    print('\nWhere would you like to go:')
    print('\n'.join(actions))
    while True:
      items = input('\nEnter choice (fbi or lab): ')
# Code goes to FBI map
      if items == 'FBI' or items == 'fbi':
        while True:
          modulename = 'fbi'
          if modulename not in sys.modules:
            import fbi as fbi
            break
          else:
            importlib.reload(sys.modules['fbi'])
            import fbi as fbi
            break
          break
      elif items == 'Lab' or items == 'lab':
        while True:
          modulename = 'lab'
          if modulename not in sys.modules:
            import lab as lab
            break
          else:
            importlib.reload(sys.modules['lab'])
            import lab as lab
            break
          break
      else:
        print("Invalid.")
    break
  if do == 'quit':
    print('Goodbye.')
    exit()
  else:
     print("That is not an option.")
