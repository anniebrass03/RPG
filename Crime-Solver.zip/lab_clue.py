from maps import data, data_1
import sys, importlib

# Statement for the lab clue
print("Here is your clue:")
print ('It is the unimportant things said that matter.\n')


# Class for possible moves to make on lab clue position
class Clue:
  while True:
    print('Map for Lab:')
    # Map for lab
    for i in range(len(data_1)):
        for j in range(len(data_1[i])):
          print(data_1[i][j], end='  ')
        print()
    f = input('\nstart or hair: ')
    if f == 'start' or f == 'Start':
      importlib.reload(sys.modules['lab'])
      import lab as lab
      break
    if f == 'hair' or f == 'Hair':
      while True:
        modulename = 'hair'
        if modulename not in sys.modules:
          import hair as hair
          break
        else:
          importlib.reload(sys.modules['hair'])
          import hair as hair
          break
        break
    else:
      print('Invalid, please input valid answer.\n')
