from maps import data, data_1
import sys, importlib


# Starting sentences for Blake Morris
print("You are going to interrogate Blake Morris.\n")
print("Questions:")
print("1. Where were you the Monday morning?")
print("2. How was your relationship with the victim?")

# While loop for interrogating Blake Morris
while True:
  convo = input('1 or 2: ')
# Code for if player chooses question 1
  if convo == '1':
    print('B: I was walking to work, my car is in the shop.\n')
    print('\n1. Did you see the victim on your walk?')
    print('2. Why not take a cab?')
    a = input('1 or 2: ')
    if a == '1':
      print('B: No, I avoided seeing people, it was too early\n')
      print ('We are done here, I will be in touch.\n')
      print ('Where would you like to go next?')
      break
    if a == '2':
      print('B: I try to be earth conscious when I can.')
      print ('We are done here, I will be in touch.\n')
      print ('Where would you like to go next?')
      break
    else:
      print('That is not an option.')

# Code for if player chooses question 2
  if convo == '2':
    print('B: We work together at the bank. We were just colleagues.')
    print('\n1. Did you dislike him?')
    print('2. Were there issues between him and you or anyone at the bank?')
    b = input('1 or 2: ')
    if b == '1':
      print ('B: The only issue is when he borrowed your pencil and never gave it back.')
      print ('We are done here, I will be in touch.\n')
      print ('Where would you like to go next?')
      break
    if b == '2':
      print ('B: Ya, a small one about a wrong coffe order, we got over it.')
      print ('\nWe are done here, I will be in touch.\n')
      print ('Where would you like to go next?')
      break

# Code for if player believes they solved the crime
  if convo == 'solved' or convo == 'Solved':
    import ending as ending
    break

# Code for when player inputs invalid answer
  else:
    print('Invalid answer, please input valid answer')


# Class for when player is on the Blake position on map
class Blake:
  # While loop for different moves on the map
  print('FBI map:')
  while True:
    # Map for FBI
    for i in range(len(data)):
        for j in range(len(data[i])):
          print(data[i][j], end='  ')
        print()
    f = input('\nstart or lab: ')
    if f == 'start' or f == 'Start':
      while True:
        modulename = 'fbi'
        if modulename not in sys.modules:
          import fbi as fbi
          break
        else:
          importlib.reload(sys.modules['fbi'])
          import fbi as fbi
          break
        break
    if f == 'lab' or f == 'Lab':
      while True:
        modulename = 'lab'
        if modulename not in sys.modules:
          import lab as lab
          break
        else:
          importlib.reload(sys.modules['lab'])
          import lab as lab
          break
        break
    else:
      print('Invalid, please input valid answer.')
      break
    break
