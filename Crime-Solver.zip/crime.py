import sys, time, os

# Congradulation statement and the story of the crime
con = """\nCongratulation!!\n\
You solved the murder! Joel was responsible at
work but he was not very good at taking care of
his property. Patty constantly gave him warnings 
to clean his yard up. She snapped.
While watering her plants saw Joel leaving his
house. She followed him to the park and hit
him in the head with a rock. Luckly for us
she stepped on a ripped piece of fabric at
the crime scene. We got a warrant and found
the rock in her backyard, by then she broke
and told us everything.\nGood job detective."""


# Code to create a typing effect for the congradulations
def typewriter(con):
  for message in con:
    sys.stdout.write(message)
    sys.stdout.flush()

    if message != "\n":
      time.sleep(0.1)
    else:
      time.sleep(1)

typewriter(con)

exit()