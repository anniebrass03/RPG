from maps import data, data_1
import sys, importlib

# While loop for when player analysing hair
while True:
  print("You are examining the hair.")
  print("Would you like to use the finger print scanner or the mass-spec?")
  h = input('mass-spec or fingerprint: ')
  if h == 'mass-spec':
    print('There were no unexpected particulates on the hair.')
    break
  if h == 'fingerprint' or h == 'Fingerprint':
    print('There are no prints on the hair.')
    break
  else:
    print('Invalid response')


# Class for possible moves to make on hair position
class Hair:
    # While loop for where player will move
  while True:
    print("\nWhere would you like to go?")
    print("Map for Lab:\n")
# Code to print out the Lab map
    for i in range(len(data_1)):
      for j in range(len(data_1[i])):
        print(data_1[i][j], end='  ')
      print()
    f = input('\nblue fabric or clue: ')
    if f == 'blue fabric' or f == 'Blue fabric':
      while True:
        modulename = 'blue_fabric'
        if modulename not in sys.modules:
          import blue_fabric as blue_fabric
          break
        else:
          importlib.reload(sys.modules['blue_fabric'])
          import blue_fabric as blue_fabric
          break
        break
    if f == 'Clue' or f == 'clue':
      while True:
        modulename = 'lab_clue'
        if modulename not in sys.modules:
          import lab_clue as lab_clue
          break
        else:
          importlib.reload(sys.modules['lab_clue'])
          import lab_clue as lab_clue
          break
        break
    else:
      print('Invalid, please input valid answer.')
