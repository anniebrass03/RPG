import sys, time, os

# Welcome message
start = "Welcome to Crime Solver.\n\
You are here to solve and catch a killer.\nGoodluck detective!\n"


# Code to give welcome message a type writer effect
def typewriter(start):
  for message in start:
    sys.stdout.write(message)
    sys.stdout.flush()

    if message != "\n":
      time.sleep(0.1)
    else:
      time.sleep(1)

typewriter(start)

# Directions for the game
rules = """\nThere are some directions.
When you solved the crime go to the nearest room
(lab or fbi). You will be able to type 'solved'
you will be asked to provide a suspect name and
the evidence that connected the suspect.
If you are wrong you return to the game,
if you are right you win.\n"""


# Code to give rules a type writer effect
def typewriter_rules(start):
  for message in rules:
    sys.stdout.write(message)
    sys.stdout.flush()

    if message != "\n":
      time.sleep(0.1)
    else:
      time.sleep(1)

typewriter_rules(rules)

# Storyline
story = "\nJoel Mann was a great family man.\n\
He had a stable job as banker and was loved by everyone he knew.\n\
A Monday morning Joel went for a walk in the park.\n\
Sadly he never made it back home, his body was found in the park bushes.\n\
Catch the person who did this!\n"


# Code to give story a type writer effect
def typewriter_story(start):
  for message in story:
    sys.stdout.write(message)
    sys.stdout.flush()

    if message != "\n":
      time.sleep(0.1)
    else:
      time.sleep(1)

typewriter_story(story)
