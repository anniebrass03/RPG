from maps import data, data_1
import sys, importlib

# While loop for when player analysing pencil
while True:
  print("Would you like to use the finger print scanner or the mass-spec?")
  sc = input('mass-spec or fingerprint: ')
  if sc == 'mass-spec':
    print('The pencil went to the mass-spec.There is nothing on the pencil.')
    break
  if sc == 'fingerprint' or sc == 'Fingerprint':
    print('There is a fingerprint on the pencil, it belongs to Blake Morris.')
    break
  else:
    print ('Invalid.')


# Class for possible moves to make on pencil position
class Pencil:
  while True:
    print("Map for Lab:\n")
# Code to print out the Lab map
    for i in range(len(data_1)):
      for j in range(len(data_1[i])):
        print(data_1[i][j], end='  ')
      print()
    f = input('\nstart or fbi: ')
    if f == 'start' or f == 'Start':
      while True:
        modulename = 'lab'
        if modulename not in sys.modules:
          import lab as lab
          break
        else:
          importlib.reload(sys.modules['lab'])
          import lab as lab
          break
        break
    if f == 'FBI' or f == 'fbi':
      while True:
        modulename = 'fbi'
        if modulename not in sys.modules:
          import fbi as fbi
          break
        else:
          importlib.reload(sys.modules['fbi'])
          import fbi as fbi
          break
        break
    else:
      print('Invalid, please input valid answer.')
