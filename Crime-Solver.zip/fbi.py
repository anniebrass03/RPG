from maps import data, data_1
import sys, importlib


print("Map for FBI:\n")
# Code to print out FBI map
for i in range(len(data)):
  for j in range(len(data[i])):
    print(data[i][j], end='  ')
  print()

# While loop for moves available to make on starting position
while True:
  print('\nEnter one of the following directions:')
  ways = [
      '\n* up (Patty)',
      '* down (Blake)',
      '* right (Lab)',
      '* solved (if you believe you have the answer)'
      ]
  print('\n'.join(ways))
  direct = input('\nEnter direction: ')
  if direct == 'down' or direct == 'Down':
    while True:
      modulename = 'blake'
      if modulename not in sys.modules:
        import blake as blake
        break
      else:
        importlib.reload(sys.modules['blake'])
        import blake as blake
        break
    break
  if direct == 'right':
    while True:
      modulename = 'lab'
      if modulename not in sys.modules:
        import lab as lab
        break
      else:
        importlib.reload(sys.modules['lab'])
        import lab as lab
        break
    break
  if direct == 'up':
    while True:
      modulename = 'patty'
      if modulename not in sys.modules:
        import patty as patty
        break
      else:
        importlib.reload(sys.modules['patty'])
        import patty as patty
        break
      break
  if direct == 'solved' or direct == 'Solved':
    while True:
        modulename = 'ending'
        if modulename not in sys.modules:
          import ending as ending
          break
        else:
          importlib.reload(sys.modules['ending'])
          import ending as ending
          break
        break
  else:
    print("Invalid.")
