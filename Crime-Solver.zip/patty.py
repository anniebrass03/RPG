from maps import data, data_1
import sys, importlib

# Starting sentences for Patty Rose
print("You are going to interview Patty Rose.\n")
print("Questions:")
print("1. Do you have an alibi for Monday morning.")
print("2. How was your relationship with the victim?")

# While loop for interrogating Patty Rose
while True:
  convo = input('1 or 2: ')
# Code for if player chooses question 1
  if convo == '1':
    print('P: I was at home all morning, I live alone.\n')
    print('1. What were you doing at your house?')
    print('2. Do you have a job?')
    d = input('1 or 2:')
    if d == '1':
      print('P: I broke my foot, I was resting.')
      print('Ok, we are done here.\n')
      break
    if d == '2':
      print('P: No, I am retired.')
      print('Ok, what were you doing home Moday morning?')
      print('P: I broke my foot, I was resting.')
      print('Ok, we are done here.\n')
      break
    break

# Code for if player chooses question 2
  if convo == '2':
    print('P: We were neighbours. He was a messy neighbour, it annoyed me.')
    print('\n1. Why are you so tense?')
    e = input('Input 1: ')
    if e == '1':
      print('P: Because I am being accused of a murder I did not commit!')
      print('I am sorry it is just protocol. We will be in touch.')
      break

# Code for if player believes they solved the crime
  if convo == 'solved' or convo == 'Solved':
    import ending as ending
    break

# Code for when player inputs invalid answer
  else:
    print('Invalid answer, please input valid answer')


# Class for possible moves to make on Patty Rose position
class Patty:
  while True:
    # Map for FBI
    for i in range(len(data)):
        for j in range(len(data[i])):
          print(data[i][j], end='  ')
        print()
    f = input('\nstart or clue: ')
    if f == 'start' or f == 'Start':
      importlib.reload(sys.modules['fbi'])
      import fbi as fbi
      break
    elif f == 'clue' or f == 'clue':
      while True:
        modulename = 'fbi_clue'
        if modulename not in sys.modules:
          import fbi_clue as fbi_clue
          break
        else:
          importlib.reload(sys.modules['fbi_clue'])
          import fbi_clue as fbi_clue
          break
        break
    else:
      print('Invalid, please input valid answer.')
      break
    break
