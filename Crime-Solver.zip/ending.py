import sys, time, os
from maps import data, data_1
import sys, importlib

# Instructions to input player's answer
print ("Did you solve the crime?")
inst = """\nPlease type the suspects first name and
the piece of evidence that connects the suspects
to the crime.\n\nEx. Name, Evidence 
(Upper case letter for start of name and evidence with comma in between)"""
print (inst)

# While loop with all the possible answers
while True:
  # Code for the correct answer
  solve = input('Answer: ')
  if solve == ('Patty, Blue fabric'):
    print ('You have solved the murder!')
    while True:
      modulename = 'crime'
      if modulename not in sys.modules:
        import crime as crime
        break
      else:
        importlib.reload(sys.modules['crime'])
        import crime as crime
        break
      break

  elif solve == ('Patty, Hair'):
    print('That is not good, go do some more investigating!')
    while True:
      modulename = 'main'
      if modulename not in sys.modules:
        import main as main
        break
      else:
        importlib.reload(sys.modules['main'])
        import main as main
        break
      break

  elif solve == ('Blake, Pencil'):
    print ('You answer is not right, go back.')
    while True:
      modulename = 'main'
      if modulename not in sys.modules:
        import main as main
        break
      else:
        importlib.reload(sys.modules['main'])
        import main as main
        break
      break

  elif solve == ('Patty, Pencil'):
    print('Are you trying to get fired, go back and look a bit harder!')
    while True:
      modulename = 'main'
      if modulename not in sys.modules:
        import main as main
        break
      else:
        importlib.reload(sys.modules['main'])
        import main as main
        break
      break

  elif solve == ('Blake, Blue fabric'):
    print('That is not good, go do some more investigating!')
    while True:
      modulename = 'main'
      if modulename not in sys.modules:
        import main as main
        break
      else:
        importlib.reload(sys.modules['main'])
        import main as main
        break
      break

  elif solve == ('Blake, Hair'):
    while True:
      modulename = 'main'
      if modulename not in sys.modules:
        import main as main
        break
      else:
        importlib.reload(sys.modules['main'])
        import main as main
        break
      break

  else:
    print ('Invalid answer, please input answer as such: Name, Evidence')
